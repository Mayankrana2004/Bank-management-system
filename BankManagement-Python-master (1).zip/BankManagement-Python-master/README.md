# BankManagement-Python
This is a practice project in Python. Here i have build a BankManagement System using python Tlinter module and MySQL Database.
